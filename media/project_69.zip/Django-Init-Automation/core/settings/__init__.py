from core.settings.development import *

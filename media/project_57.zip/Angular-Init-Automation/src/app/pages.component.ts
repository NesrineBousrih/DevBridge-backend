import { Component } from '@angular/core';

@Component({
  selector: 'app-pages',
  standalone: true,
  imports: [],
  template: `
    <p>
      pages works!
    </p>
  `,
  styles: ``
})
export class PagesComponent {

}

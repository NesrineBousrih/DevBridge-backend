from core.env import config
from core.settings.base import *


DEBUG = config("DEBUG")

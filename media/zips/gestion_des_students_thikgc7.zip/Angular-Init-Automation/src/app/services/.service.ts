import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {  } from '../models/.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class Service {
  private baseUrl = `${environment.apiUrl}/gestion des students/`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<[]> {
    return this.http.get<[]>(this.baseUrl);
  }

  getOne(id: number): Observable<> {
    return this.http.get<>(`${this.baseUrl}/${id}`);
  }

  create(data: ): Observable<> {
    return this.http.post<>(this.baseUrl+"/", data);
  }

  update(id: number, data: ): Observable<> {
    return this.http.put<>(`${this.baseUrl}/${id}/`, data);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}/`);
  }
}

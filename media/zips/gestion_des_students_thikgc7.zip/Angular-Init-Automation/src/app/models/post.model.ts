export interface Post {
  id?: number;
  title: string;
}

export const environment = {
  production: true,
  apiUrl: '${API_URL}'
};
